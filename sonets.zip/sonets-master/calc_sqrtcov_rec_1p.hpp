int calc_sqrtcov_given_rhos
(int N, double p, double rho_recip, double rho_conv, 
 double rho_div, double rho_chain, double rho_noshare,
 double &sqrt_diag, double &sqrt_recip, double &sqrt_conv,
 double &sqrt_div, double &sqrt_chain, double &sqrt_noshare);
