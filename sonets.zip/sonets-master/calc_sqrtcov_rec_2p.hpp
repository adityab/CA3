int calc_sqrtcov_given_rhos
(int N[], double (*p)[2], double (*rho_recip)[2], double (*rho_conv)[2][2], 
 double (*rho_div)[2][2], double (*rho_chain)[2][2], 
 double (*sqrt_diag)[2], double (*sqrt_recip)[2], double (*sqrt_conv)[2][2], 
 double (*sqrt_div)[2][2], double (*sqrt_chain)[2][2]);
