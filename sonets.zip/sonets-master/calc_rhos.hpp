double calc_rho_given_alpha(double p1, double p2, double alpha,
			    int &status);
double calc_alpha_given_rho(double p1, double p2, double rho, int &status);
